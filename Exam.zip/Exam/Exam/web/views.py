from django.shortcuts import render, redirect

from Exam.common.profile_helpers import get_profile
from Exam.web.forms import CreateProfileForm


def create_profile(request):
    form = CreateProfileForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('index')

    context = {
        'form': form,
        "no_nav": True,
    }
    return render(request, 'profiles/profile-create.html', context)


def index(request):
    profile = get_profile()

    if profile is None:
        return create_profile(request)

    return render(request, 'web/index.html')
