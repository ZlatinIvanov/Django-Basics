from django.contrib.auth.mixins import LoginRequiredMixin
from django.forms import modelform_factory
from django.views import generic as views
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView

from Exam.cars.forms import CarForm
from Exam.cars.models import Car
from Exam.common.profile_helpers import get_profile



class ReadonlyViewMixin:
    def get_form(self, form_class=None):
        form = super().get_form(form_class=form_class)

        for field in form.fields.values():
            field.widget.attrs["readonly"] = "readonly"

        return form

def catalogue(request):

    context = {
        'cars': Car.objects.all(),
    }
    return render(request, 'cars/catalogue.html', context)


class CreateCarView(views.CreateView):
    queryset = Car.objects.all()
    fields = ('type', 'model', 'year', 'image_url', 'price')
    template_name = 'cars/car-create.html'
    success_url = reverse_lazy('catalogue')

    def form_valid(self, form):
        form.instance.owner_id = get_profile().pk
        return super().form_valid(form)


class DetailsCarView(views.DetailView):
    queryset = Car.objects.all()
    template_name = 'cars/car-details.html'


class EditCarView(views.UpdateView):
    model = Car
    template_name = 'cars/car-edit.html'
    fields = ('type', 'model', 'year', 'image_url', 'price')
    success_url = reverse_lazy('catalogue')


class DeleteCarView(ReadonlyViewMixin, views.DeleteView):

    model = Car
    template_name = 'cars/car-delete.html'

    form_class = modelform_factory(
        Car,
        fields=('type', 'model', 'year', 'image_url', 'price'),
    )
    success_url = reverse_lazy('catalogue')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["instance"] = self.object
        return kwargs

