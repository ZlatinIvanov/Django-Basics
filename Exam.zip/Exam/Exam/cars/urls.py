from django.urls import path, include

from Exam.cars.views import CreateCarView, catalogue, DeleteCarView, EditCarView, DetailsCarView

urlpatterns = [
    path('catalogue/', catalogue, name='catalogue'),
    path('create/', CreateCarView.as_view(), name='create_car'),
    path('<int:pk>/',
         include([
            path('details/', DetailsCarView.as_view(), name='car_details'),
            path('delete/', DeleteCarView.as_view(), name='delete_car'),
            path('edit/', EditCarView.as_view(), name='edit_car'),
         ])
    )
]