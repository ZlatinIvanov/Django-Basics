from django.core.exceptions import ValidationError
from django.core.validators import MinLengthValidator, MinValueValidator, MaxValueValidator
from django.db import models

from Exam.profiles.models import Profile


class Car(models.Model):
    TYPE_CHOICES = (
        ("Rally", "Rally"),
        ("Open-wheel", "Open-wheel"),
        ("Kart", "Kart"),
        ("Drag", "Drag"),
        ("Other", "Other"),
    )

    type = models.CharField(
        max_length=10,
        null=False,
        blank=False,
        choices=TYPE_CHOICES
    )
    model = models.CharField(
        max_length=15,
        validators=(
            MinLengthValidator(1),
        ),
        null=False,
        blank=False,
    )
    year = models.IntegerField(
        null=False,
        blank=False,
        validators=(
            MinValueValidator(1999, message="Year must be between 1999 and 2030!"),
            MaxValueValidator(2030, message="Year must be between 1999 and 2030!")
        )
    )
    image_url = models.URLField(
        null=False,
        blank=False,
        unique=True,
        default="https://...",
        error_messages={'unique': "This image URL is already in use! Provide a new one."},
    )
    price = models.FloatField(
        null=False,
        blank=False,
        validators=(
            MinValueValidator(1.0),
        )
    )
    owner = models.ForeignKey(
        to=Profile,
        on_delete=models.CASCADE,
    )

    class Meta:
        verbose_name = "Car"
        verbose_name_plural = "Cars"