from django.core.validators import MinLengthValidator, MinValueValidator
from django.db import models
from Exam.profiles.validators import validate_username, validate_min_length


class Profile(models.Model):
    username = models.CharField(
        null=False,
        blank=False,
        unique=True,
        max_length=15,
        validators=(
            MinLengthValidator(3),
            validate_username,
            validate_min_length),
    )
    email = models.EmailField(
        unique=True,
        null=False,
        blank=False,
    )
    age = models.IntegerField(
        help_text="Age requirement: 21 years and above.",
        null=False,
        blank=False,
        validators=(MinValueValidator(21),),
    )
    password = models.CharField(
        null=False,
        blank=False,
        max_length=20,
    )
    first_name = models.CharField(
        max_length=25,
        blank=True,
        null=True,
    )
    last_name = models.CharField(
        max_length=25,
        blank=True,
        null=True,
    )
    profile_picture = models.URLField(
        blank=True,
        null=True,
    )

