from django.core.exceptions import ValidationError


def validate_username(username):
    is_valid = all(ch.isalnum() or ch == '_' for ch in username)

    if not is_valid:
        raise ValidationError("Username must contain only letters, digits, and underscores!")


def validate_min_length(value):
    if len(value) < 3:
        raise ValidationError("Username must be at least 3 chars long!")